# Military Approach to Security – Portfolio (No‑dependency version)

This is a **plain HTML/CSS/JS** version (no Tailwind or external CDNs). It avoids common GitHub Pages issues like blocked CDNs or CSP errors.

## Files
- `index.html` — single file site.
- `.nojekyll` — ensures GitHub serves files as‑is.

## Publish on GitHub Pages
1. Create a **public** repository (e.g., `military-portfolio`).
2. Upload `index.html` and `.nojekyll` to the **root** of the repo.
3. Go to **Settings → Pages** → **Deploy from a branch** → Branch **main**, Folder **/** (root). Click **Save**.
4. Wait a minute and refresh. Your site will be: `https://<your-username>.github.io/military-portfolio/`

### Troubleshooting (most common)
- **404 or theme page appears:** Ensure you set **Folder** to **/** (root), not `/docs`, unless your files live in `/docs`.
- **Site doesn’t build:** Repo must be **public** (unless you’re on a paid plan with private Pages).
- **Blank styling:** If using a CDN-based version, some networks block external scripts. This plain version fixes that.
- **Wrong URL:** GitHub Pages is case sensitive. Check the repository name and URL casing.
- **Cached old version:** Hard refresh (Ctrl/Cmd+Shift+R).

## Custom domain (optional)
After it’s live, add your domain in **Settings → Pages → Custom domain** and follow the DNS instructions.
