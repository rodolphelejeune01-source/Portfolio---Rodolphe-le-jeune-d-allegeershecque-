# Military Approach to Security – Portfolio (GitHub Pages)

This package contains a ready‑to‑publish single‑file website for your portfolio.

## Files
- `index.html` — the website (no build tools required).
- `.nojekyll` — disables Jekyll so files are served as‑is (harmless to include).

## Publish with GitHub Pages (project site)
1. Create a new repository on GitHub (e.g., `military-portfolio`). Keep it **public**.
2. Upload `index.html` and `.nojekyll` to the root of the repo (or push via Git).
3. In **Settings → Pages**, set the site to publish from the **main** branch and **/** (root).
4. Save. Your site link will appear in the Pages section (e.g., `https://<your-username>.github.io/military-portfolio/`).

### Publish as a user site (optional)
If you want the site at the root domain `https://<your-username>.github.io/`:
1. Create a repo named exactly `<your-username>.github.io` (public).
2. Add `index.html` and `.nojekyll` to the root.
3. Enable Pages if needed in **Settings → Pages** (main branch, root).

## Update content
Edit `index.html` directly (you can keep everything in one file). Commit and push — the site redeploys automatically.

## Custom domain (optional)
After the site is live, add your domain in **Settings → Pages** under Custom domain. Point your DNS to GitHub Pages (A/AAAA + CNAME) as documented.

## Local preview (optional)
Just double‑click `index.html` to open it in your browser.
